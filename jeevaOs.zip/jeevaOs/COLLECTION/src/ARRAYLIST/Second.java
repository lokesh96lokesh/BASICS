package ARRAYLIST;

import java.util.ArrayList;
import java.lang.*;

public class Second {
	
	public static void main(String[] args) {
		ArrayList<Object>nums=new ArrayList<>();
		nums.add(10);
		nums.add(23);
		nums.add(45);
		nums.add(32);
		nums.add(56);
		nums.add("Jeeva");
		nums.add(2.5f);
		nums.add(1);
		nums.add(68);
		nums.add(45);
		nums.add(65);
		nums.add(90);
		nums.add(2);
		System.out.println(nums);
//		for(Integer x : nums) {
//			//System.out.println(x);
//			if(x%2==0) {
//				System.out.println("Even Number:"+x);
//			}
//			if(x%2==1) {
//				System.out.println("Odd Number:"+x);
//			}
//		}
//		int max=nums.get(0);
//		for(Integer x:nums) {
//			if(x>max)
//				max=x;
//		}
//		System.out.println(max);
//		nums.forEach(b->{if(b%2==0)System.out.println(b);});
//		nums.forEach(b->{
//			if(b%2==0)
//			System.out.println(b);
//		});
	}

	private static void Second(Object obj) {
		// TODO Auto-generated method stub
		
	}

}
