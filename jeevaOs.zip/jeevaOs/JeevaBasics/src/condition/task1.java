package condition;

public class task1 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=40;
		int d=50;
		if(a>b&&a>c&&a>d)
			System.out.println("A is biggest value");
		else if(b>a&&b>c&&b>d)
			System.out.println("B is biggest value");
		else if(c>a&&c>b&&c>d)
			System.out.println("c is the biggest value");
		else
			System.out.println("d is the biggest value");

	}

}
