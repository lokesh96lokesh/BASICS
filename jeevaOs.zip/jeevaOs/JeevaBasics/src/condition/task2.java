package condition;

public class task2 {

	public static void main(String[] args) {
		int a =40;
		if(a>=90)
			System.out.println("first mark");
		else if(a>=80)
			System.out.println("seconf mark");
		else if(a>=50)
			System.out.println("third mark");
		else 
			System.out.println("failed");

	}

}
