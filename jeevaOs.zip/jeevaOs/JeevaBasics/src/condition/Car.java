package condition;

public class Car {
	String brand;
	String model;
	int engineeCC;
	int price;
	int taxPercentage;
	int netPrice;
	
	Car(String brand,String model,int engineeCC,int price,int taxPercentage){
		this.brand=brand;
		this.model=model;
		this.engineeCC=engineeCC;
		this.price=price;
		this.taxPercentage=taxPercentage;
		this.netPrice=price+(price*taxPercentage/100);
	}
}


