package condition;

public class task4 {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		String total="subtraction";
		switch (total) {
		case "addition":
			System.out.println(a+b);
			break;
		case "subtraction":
			System.out.println(a-b);
			break;
		case "multiplication":
			System.out.println(a*b);
			break;
		case "division":
			System.out.println(a/b);
			break;
		default:
			System.out.println("Enter the valid value and check the  crct spellings");
		}

	}

}
