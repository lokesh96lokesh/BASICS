package condition;

public class task5 {

	public static void main(String[] args) {
		String month="january";
		switch (month) {
		case "jan":
			System.out.println("This is the first month of the year");
			break;
		case "feb":
			System.out.println("This is the second month of the year and my birthday month also");
			break;
		case "mar":
			System.out.println("This is the first month of the year");
			break;
		case "apr":
			System.out.println("This is the first month of the year");
			break;
		case "may":
			System.out.println("This is the first month of the year");
			break;
		case "june":
			System.out.println("This is the first month of the year");
			break;
		case "july":
			System.out.println("This is the first month of the year");
			break;
		case "aug":
			System.out.println("This is the first month of the year");
			break;
		case "sep":
			System.out.println("This is the first month of the year");
			break;
		case "oct":
			System.out.println("This is the first month of the year");
			break;
		case "nov":
			System.out.println("This is the first month of the year");
			break;
		case "dec":
			System.out.println("This is the first month of the year");
			break;
		default:
			System.out.println("Please entered correct details and check the spelling also");
			break;
		}

	}

}
