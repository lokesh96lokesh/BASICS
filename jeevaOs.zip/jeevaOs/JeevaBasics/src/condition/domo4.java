package condition;

public class domo4 {

	public static void main(String[] args) {
		int a=-13;
		if(a==0)
			System.out.println("The give no is newtral");
		else if (a>=0)
			System.out.println("the given no is positive");
		else
			System.out.println("The given no is negative");


	}

}
