package condition;

public class demo1 {

	public static void main(String[] args) {
		int age=18;
		if (age>=18) {
			System.out.println("Eligible for vote");
		} else {
			System.out.println("Not eligible for vote");
		}

	}

}
