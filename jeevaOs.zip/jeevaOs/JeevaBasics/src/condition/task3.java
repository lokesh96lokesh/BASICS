package condition;

public class task3 {

	public static void main(String[] args) {
		int a=8;
		switch (a) {
		case 1: 
			System.out.println("First day");
			break;
		case 2:
			System.out.println("Second day");
			break;
		case 3:
			System.out.println("Third day");
			break;
		case 4:
			System.out.println("Fourth day");
			break;
		case 5:
			System.out.println("Fifth day");
			break;
		case 6:
			System.out.println("sixth day");
			break;
		case 7:
			System.out.println("Seventh day");
			break;
		default:
			System.out.println("Please enter the valid details....");;
		}


	}

}
