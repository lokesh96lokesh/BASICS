package condition;

public class UseCar {
	public static void main(String[] args) {
		Car car1 = new Car("Audi","A6",3500,500000,10);
		Car car2= new Car("BMW","X6",4200,400000,15);
		Car car3 = new Car("Jaguar","FPACE",5000,900000,10);
		Car[] cars= {car1,car2,car3};
//		for(int i=0;i<cars.length;i++) {
//			//System.out.println("Brands:"+cars[i].brand+"--- Models:"+cars[i].model+"--- EngineCC:"+cars[i].engineeCC+"--- NetPrice:"+cars[i].netPrice);
//			System.out.print("Brands:"+cars[i].brand);
		//}
//		for(Car car:cars) {
//			System.out.println(car.brand +"---"+car.model);
//		}
		for(Car car:cars) {
			if(car.price<=500000)
				System.out.println(car.brand +" "+car.price);
		}
	}
}


//Car car1 = new Car("Audi", "A6", 3500, 500000, 10)
