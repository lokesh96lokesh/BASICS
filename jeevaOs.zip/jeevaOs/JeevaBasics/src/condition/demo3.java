package condition;

public class demo3 {
	public static void main(String args[]) {
		String a="jeeva";
		if(a.contains("a")||a.contains("e")||a.contains("i")) {
			System.out.println("It is vowels");
			
		}
		else
			System.out.println("Not a Vowels");
	}

}
