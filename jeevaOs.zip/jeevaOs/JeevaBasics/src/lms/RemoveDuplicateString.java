package lms;

public class RemoveDuplicateString {

	public static void main(String[] args) {
		String a="i am prabhu and i am from canada  prabh";
		String nums[]= a.split(" ");

        for (int i = 0; i < nums.length; i++) {
            boolean isDuplicate = false;

            // Check if nums[i] appeared before in the array
            for (int j = 0; j < i; j++) {
                if (nums[i].equals(nums[j])) {
                    isDuplicate = true;
                    break;
                }
            }

            // Print only if it has not appeared before
            if (!isDuplicate) {
                System.out.print(nums[i] + " ");
            }
        }

	}

}
