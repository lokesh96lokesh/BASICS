package lms;

public class StringSortWithLoops {
	    public static void main(String[] args) {
	        String str = "abfcd";  // Input string

	        // Convert string to character array
	        char[] charArray = str.toCharArray();

	        // Bubble Sort using for loops
	        for (int i = 0; i < charArray.length - 1; i++) {
	            for (int j = 0; j < charArray.length - 1 - i; j++) {
	                // If the character at j is greater than the character at j+1, swap them
	                if (charArray[j] > charArray[j + 1]) {
	                    char temp = charArray[j];
	                    charArray[j] = charArray[j + 1];
	                    charArray[j + 1] = temp;
	                }
	            }
	        }

	        // Convert the sorted character array back to a string
	        String sortedString = new String(charArray);

	        // Print the sorted string
	        System.out.println("Sorted String: " + sortedString);
	    }
}



