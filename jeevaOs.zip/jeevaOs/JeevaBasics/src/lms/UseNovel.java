package lms;

public class UseNovel {
	public static void main(String[] args) {
		Novel no1= new Novel();
		Novel no2= new Novel();
		Novel no3= new Novel();
		no1.setid(10);
		no2.setid(11);
		no3.setid(12);
		no1.setauthor("jeevan");
		no2.setauthor("jeevan");
		no3.setauthor("dinesh");
		no1.settitle("developer");
		no2.settitle("tester");
		no3.settitle("fullstack");
		no1.setprice(100);
		no2.setprice(200);
		no3.setprice(300);
		no1.setpages(1);
		no2.setpages(2);
		no3.setpages(3);
		Novel a[]= {no1,no2,no3};
		int totalPrice=0;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i].author.equals(a[j].author))
					System.out.println(a[i].author+" "+"SAME AUTHOR"+" "+a[j].author);
				else
					System.out.println(a[i].author+" "+"DIFFRENT AUTHOR"+" "+a[j].author);
				
			}
			totalPrice=totalPrice+a[i].price;
		//System.out.println(a[i].id+" "+a[i].author+" "+a[i].title+" "+a[i].price+" "+a[i].pages);

		}
		System.out.println("TotalPrice: "+totalPrice);
		System.out.println(no1.getauthor());
	}
}

class Novel {
	int id;
	String author;
	String title;
	int price;
	int pages;
	public void setid(int id) {
		this.id=id;
	}
	public void setauthor(String author) {
		this.author=author;
	}
	public void settitle(String title) {
		this.title=title;
	}
	public void setprice(int price) {
		this.price=price;
	}
	public void setpages(int pages) {
		this.pages=pages;
	}
	public int getid() {
		return id;
	}
	public String getauthor() {
		return author;
	}
	public String gettitle() {
		return title;
	}
	public int getprice() {
		return price;
	}
	public int getpages() {
		return pages;
	}
}







