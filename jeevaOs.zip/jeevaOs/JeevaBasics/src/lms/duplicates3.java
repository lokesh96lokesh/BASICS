package lms;

public class duplicates3 {

	public static void main(String[] args) {
		String a="aray";
		char []b=a.toCharArray();
		//int count=0;
		for(int i=0;i<b.length;i++) {
			int count=1;
			for(int j=i+1;j<b.length;j++) {
				if(b[i]==b[j]) {
					count++;
					b[j]='$';
				}	
			}
			if(count>1&&b[i]!='$')
				System.out.println(b[i]+"-"+count);
		}

	}

}
