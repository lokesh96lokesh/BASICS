package lms;

public class duplicateCounter {
    public static void main(String[] args) {
        String a = "bottle"; // Example string
        char input[]=a.toCharArray();
        int duplicateCount = 0;
        int uniqueCount = 0;

        for (int i = 0; i < input.length; i++) {
            
            boolean isDuplicate = false;
            boolean isCounted = false;

            // Check if the character has already been counted
            for (int j = 0; j < i; j++) {
                if (input[i] == input[j]) {
                    isCounted = true;
                    break;
                }
            }

            if (isCounted) {
                continue; // Skip already counted characters
            }

            // Check if it appears again in the string
            for (int k = i + 1; k < input[i]; k++) {
                if (input[i] == input[k]) {
                    isDuplicate = true;
                    break;
                }
            }

            if (isDuplicate) {
                duplicateCount++;
            } else {
                uniqueCount++;
            }
        }

        System.out.println("Duplicate Character Count: " + duplicateCount);
        System.out.println("Non-Duplicate Character Count: " + uniqueCount);
    }
}

