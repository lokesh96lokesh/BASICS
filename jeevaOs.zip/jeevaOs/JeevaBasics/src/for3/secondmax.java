package for3;

public class secondmax {

	public static void main(String[] args) {
		int num[]= {24,6,9,38,65,78,104};
		int max=num[0];
		int secmax=max;
		for(int i=0;i<num.length;i++) {
			if(num[i]>max) {
				secmax=max;
				max=num[i];
			}
			if(num[i]>secmax&&num[i]!=max) {
				secmax=num[i];
			}
		}
		System.out.println(secmax);
	}

}
