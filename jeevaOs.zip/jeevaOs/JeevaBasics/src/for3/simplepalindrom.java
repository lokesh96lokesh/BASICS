package for3;

public class simplepalindrom {

	public static void main(String[] args) {
		int a=121;
		int temp=0;
		int org=a;
		while(a>0) {
			int b=a%10;
			temp=(temp*10)+b;
			a/=10;
		}
		if(temp==org)
			System.out.println("palindrome");
	}

}
