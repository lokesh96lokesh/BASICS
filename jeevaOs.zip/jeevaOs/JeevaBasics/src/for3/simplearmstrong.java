package for3;

public class simplearmstrong {

	public static void main(String[] args) {
		int num=153;
		int org=num;
		int temp=0;
		while(num>0) {
			int mod=num%10;
			int cube=mod*mod*mod;
			temp=cube+temp;
			num/=10;
		}
		if(org==temp)
			System.out.println("armstrong");
	}

}
