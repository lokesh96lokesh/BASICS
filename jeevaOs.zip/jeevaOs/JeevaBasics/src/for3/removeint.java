package for3;

public class removeint {

	public static void main(String[] args) {
		String a="abc123def";
		char[]b=a.toCharArray();
		String rev="";
		boolean flag=true;
		for(int i=0;i<b.length;i++) {
			if(b[i]>='0'&&b[i]<='9'&&flag==true) 
			flag=false;
		else
			rev=b[i]+rev;
		}
		System.out.println(rev);
	}

}
