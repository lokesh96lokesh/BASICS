package for3;

import java.util.Scanner;

public class new1 {
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a=sc.nextInt();
		//String a=sc.nextLine();
		float b=sc.nextFloat();
		System.out.println(b+20);

	}

}
