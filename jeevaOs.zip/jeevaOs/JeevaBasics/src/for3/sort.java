package for3;

import java.util.Arrays;

public class sort {

	public static void main(String[] args) {
		int num[]= {24,6,95,38,65,78,104};
		int temp=0;
		for(int i=0;i<num.length;i++) {
			for(int j=i+1;j<num.length;j++) {
				if(num[i]>num[j]) {
					temp=num[i];
					num[i]=num[j];
					num[j]=temp;
				}
			}
			//System.out.println(num[i]);
			System.out.println(Arrays.toString(num));
		}
	}

}
