package for3;

public class thirdmax {
	public static void main(String[] args) {
		int num[]= {24,6,95,38,65,78,104};
		int max=num[0];
		int secmax=max;
		int tmax=secmax;
		for(int i=0;i<num.length;i++) {
			if(num[i]>max) {
				tmax = secmax;
				secmax=max;
				max=num[i];
			}
			if(num[i]>secmax&&num[i]!=max&&num[i] != tmax) {
				secmax=num[i];
			}
			if(num[i]>tmax&&num[i]!=max&&num[i]!=secmax)
				tmax=num[i];
		}
		System.out.println(max + " " +secmax+" "+tmax);
	}

}
