package for3;

public class one {
	public static void main(String args[]) {
		for(int i=1;i<=5;i++) {
			for(int j=i;j<=5;j++) {
				System.out.print(i);
				System.out.print(" ");
			}
			
			System.out.println();
		}
		
		
	}

}
