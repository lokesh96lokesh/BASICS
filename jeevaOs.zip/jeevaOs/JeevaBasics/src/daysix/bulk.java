package daysix;

public class bulk {

	public static void main(String[] args) {
		int num[]= {10,20,40,87};
		System.out.println(num[1]);
		System.out.println(num[3]);
		for(int i=0;i<num.length;i++)
			System.out.println(num[i]);

	}

}
