package daysix;

import java.util.Scanner;

public class practice1 {
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) {
		int a=s.nextInt();	
		int b=0;
		
		for(int i=1;i<=a;i++) {
			b=b+(i+6);
			
		}
		System.out.println(b);
		

	}

}
