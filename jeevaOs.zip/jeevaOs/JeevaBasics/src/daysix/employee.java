package daysix;

public class employee {
	String name;
	int id;
	int age;
	float salary;
	boolean isGender;

}
