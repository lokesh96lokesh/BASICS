package daysix;

public class even {

	public static void main(String[] args) {
		int num[]= {17,18,16,15,14};
		int count=0;
		int oddcount=0;
		for(int i=0;i<num.length;i++) {
			if(num[i]%2==0) {
				System.out.println(num[i]);
			count++;
			}else
				oddcount++;
		}
		System.out.println("event count is:"+count);
		System.out.println("event count is:"+oddcount);

	}

}
