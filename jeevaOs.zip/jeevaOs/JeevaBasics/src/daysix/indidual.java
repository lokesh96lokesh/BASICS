package daysix;

public class indidual {
		public static void main(String[] args) {
			String []name=new String[3];
			name[0]="jeeva";
			name[1]="dinesh";
			name[2]="thiru";
			for(int i=0;i<name.length;i++) {
				System.out.println(name[i]);
			}
			
	}
}
