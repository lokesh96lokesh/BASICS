package daysix;

public class max {
	public static void main(String args[]) {
		int num[]= {17,18,16,17,65,4};
		int max=num[0];
		for(int i=0;i<num.length;i++) {
			if(num[i]>=max)
			max=num[i];
		}
		System.out.println(max);
	}

}
