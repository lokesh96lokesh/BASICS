package daysix;

public class one {

	public static void main(String[] args) {
		String a="DAtaTYpES";
		char b[]=a.toCharArray();
		String c=a.toUpperCase();
		char d[]=c.toCharArray();
		int upper = 0,lower=0;
		for(int i=0;i<b.length;i++) {
			if(b[i]==d[i])
				upper++;
			else
				lower++;
		}
		System.out.println("upper count"+upper);
		System.out.println("lower count"+lower);

	}

}
