package daysix;

public class oddstring {
	public static void main(String[] args) {
		String [] name = {"manoj","hari","jeeva","ajay","suriy"};
		for(int i=0;i<name.length;i++) {
			if(name[i].length()%2!=0)
				System.out.println(name[i]);
		}

	}

}
