package daysix;

public class UseEmployee {
	public static void main(String[] args) {
		employee details1= new employee();
		employee details2= new employee();
		employee details3= new employee();
		employee details4= new employee();
		employee details5= new employee();
		
		details1.name="jeeva";
		details2.name="sharmi";
		details3.name="thiru";
		details4.name="divya";
		details5.name="dinesh";
		
		details1.age=23;
		details2.age=20;
		details3.age=26;
		details4.age=23;
		details5.age=27;
		
		details1.id=101;
		details2.id=102;
		details3.id=103;
		details4.id=104;
		details5.id=105;
		
		details1.salary=10000.80f;
		details2.salary=20000.40f;
		details3.salary=30000.20f;
		details4.salary=40000.10f;
		details5.salary=35000.10f;
		
		details1.isGender=true;
		details2.isGender=false;
		details3.isGender=true;
		details4.isGender=false;
		details5.isGender=true;
		
		employee [] emps= {details1,details2,details3,details4,details5};
		//age whos is greterthan 25
//		for(int i=0;i<emps.length;i++) {
//			if(emps[i].age>25)
//				System.out.println(emps[i].age);
//			//System.out.println(emps[i].name+emps[i].age+emps[i].id+emps[i].salary+emps[i].isGender);
//		}
		//maxsalary
//		employee max=emps[0];
//		for(int i=0;i<emps.length;i++) {
//			if(emps[i].salary>max.salary) {
//				max=emps[i];
//			}
//		}
//		System.out.println("name: "+max.name+", age: " +max.age+", id: "+ max.id +", Salary: "+ max.salary );
		//find a femal employee
//		for(int i=0;i<emps.length;i++) {
//			if(emps[i].isGender==false) {
//				System.out.println(emps[i].name);
//			}
//		}
		//find age between 25 and 30
		int count=0;
		for(int i=0;i<emps.length;i++) {
			if(emps[i].age>25&&emps[i].age<30) {
				count++;
				System.out.println("Name:"+emps[i].name+",Age:"+emps[i].age+",salary:"+emps[i].salary);
			}
		}
		System.out.println("count="+count);
		
	}
	

}
