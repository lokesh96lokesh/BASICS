package dayTwo;

public class Hospital {
	String name;
	String location;
	boolean isAvail24;
	

}
