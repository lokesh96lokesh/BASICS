package dayTwo;

public class demo4 {
	public static void main (String argss[]) {
		String a="javaadvance";
		System.out.println(a.charAt(4));
		System.out.println(a.length());
	}

}
