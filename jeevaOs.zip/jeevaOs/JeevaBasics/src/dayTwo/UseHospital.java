package dayTwo;

public class UseHospital {

	public static void main(String[] args) {
		Hospital hos1=new Hospital();
		Hospital hos2=new Hospital();
		Hospital hos3=new Hospital();
		hos1.name="apollo";
		hos2.name="kauvery";
		hos3.name="sims";
		hos1.location="chennai";
		hos2.location="chennai";
		hos3.location="chennai";
		
		hos1.isAvail24=true;
		hos2.isAvail24=true;
		hos3.isAvail24=true;
		
		System.out.println(hos1.name.toUpperCase()+" "+hos1.location.toUpperCase()+" "+hos1.isAvail24);
		System.out.println(hos2.name.toUpperCase()+" "+hos2.location.toUpperCase()+" "+hos2.isAvail24);
		System.out.println(hos3.name.toUpperCase()+" "+hos3.location.toUpperCase()+" "+hos3.isAvail24);
		System.out.println("Length of location is "+hos3.location.length());
		boolean a= hos1.name.equals(hos2.name);
		System.out.println(a);
		

	}

}
;