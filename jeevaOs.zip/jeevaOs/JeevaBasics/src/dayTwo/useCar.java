package dayTwo;

public class useCar {

	public static void main(String[] args) {
		car details1= new car();
		car details2= new car();
		car details3= new car();
		
		details1.brand="bmw";
		details2.brand="tata";
		details3.brand="swift";
		
		details1.model="XVI";
		details2.model="IX";
		details3.model="X2V";
		
		details1.price= 400000l;
		details2.price= 300000l;
		details3.price= 200000l;
		
		details1.isPetrol=false;
		details2.isPetrol=true;
		details3.isPetrol=true;
		
		System.out.println(details1.brand.length());
		System.out.println(details2.brand.length());
		System.out.println(details3.brand.length());
		
		System.out.println(details1.price + details2.price + details3.price);
		System.out.println(details1.brand .toUpperCase()+" "+details1.model+ " "+details1.price+ " "+details1.isPetrol);
		System.out.println(details2.brand .toUpperCase()+" "+details2.model+ " "+details2.price+ " "+details1.isPetrol);
		System.out.println(details3.brand .toUpperCase()+" "+details3.model+ " "+details3.price+ " "+details1.isPetrol);

	}

}
