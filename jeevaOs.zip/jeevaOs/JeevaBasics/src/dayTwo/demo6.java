package dayTwo;

public class demo6 {

	public static void main(String[] args) {
		String a="wonder land";
		String b="wonderland";
		boolean c= a.equalsIgnoreCase(b);
		System.out.println(c);
		
//		char m='a';
//		char n='b';
//		System.out.println(m+""+""+n);

	}

}
