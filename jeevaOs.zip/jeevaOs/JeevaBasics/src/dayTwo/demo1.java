package dayTwo;

public class demo1 {

	public static void main(String[] args) {
		String a="jeeva";
		System.out.println(a.toUpperCase());
		System.out.println(a.length());

	}

}
