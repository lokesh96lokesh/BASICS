package dayTwo;

public class practice1 {
	
	public static void main(String args[]) {
		String a="jeeva";
		System.out.println(a.toUpperCase());
		
		String b="RAZA";
		String f="Jeeva";
		System.out.println(b.toLowerCase());
		System.out.println(a.length());
		System.out.println(a.concat(b));
		
		boolean c= a.startsWith("J");
		System.out.println(c);
		boolean d= b.endsWith("b");
		System.out.println(d);
		boolean e= a.equals(f);
		System.out.println(e);
		boolean g= a.equalsIgnoreCase(f);
		System.out.println(g);
		
		boolean h= a.contains(a);
		System.out.println(h);
		char i= a.charAt(1);
		System.out.println(i);
		int j= a.indexOf("j");
		System.out.println(j);
		
		String k= "jeevanandham";
		System.out.println(k.substring(0,5));
	}

}
