package dayTwo;

public class UseLaptop {

	public static void main(String[] args) {
		laptop laptop1= new laptop();
		laptop1.brand="asus";
		laptop1.color="white";
		laptop1.price = 40000;
		laptop1.isWarranty=true;
		
		System.out.println(laptop1.brand.toUpperCase());
		System.out.println(laptop1.brand.length());
		boolean a= laptop1.brand.startsWith("d");
		System.out.println(a);
		//char[]b= laptop1.brand.toCharArray();
		System.out.println(laptop1.brand.charAt(laptop1.brand.length()-1));
		System.out.println(laptop1.color.toLowerCase());
		

	} 

}
