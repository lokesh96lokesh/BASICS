package dayTwo;

public class demo7 {

	public static void main(String[] args) {
		String a ="java,python,ch+";
		String b[]= a.split("python");
		System.out.println(b[1]);
		System.out.println(b.length);
		System.out.println(a.toLowerCase());

	}

}
