package dayTwo;

public class demo8 {
	public static void main(String args[]) {
		String a="jeeva";
		char []b= a.toCharArray();
		System.out.println(b[1]);
				
	}
}
