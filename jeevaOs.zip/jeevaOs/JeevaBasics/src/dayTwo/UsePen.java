package dayTwo;

public class UsePen {

	public static void main(String[] args) {
		pen pen1=new pen();
		pen pen2=new pen();
		
		pen1.brand="cello";
		pen2.brand="renalys";
		pen1.price=15;
		pen2.price=20;
		pen1.color="blue";
		pen2.color="black";
		System.out.println(pen1.brand.toUpperCase());
		System.out.println(pen2.brand.toUpperCase());
		boolean a=pen1.color.equals("blue");
		boolean b=pen2.color.equals("black");
		System.out.println(a);
		System.out.println(b);
		System.out.println(pen2.color.charAt(4));
		System.out.println(pen1.color.charAt(2));
		String[] c= pen1.brand.split("");
		System.out.println(c[1]);
		System.out.println(pen1.color.length());
		System.out.println(pen2.color.length());
		
		

		
		

	}

}
