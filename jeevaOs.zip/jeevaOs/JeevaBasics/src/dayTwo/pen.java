package dayTwo;

public class pen {
	String brand;
	int price;
	String color;
	
}
