package dayTwo;

public class laptop {
	String brand;
	int price;
	String color;
	boolean isWarranty;
	

}
