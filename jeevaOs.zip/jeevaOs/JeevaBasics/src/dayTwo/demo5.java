package dayTwo;

public class demo5 {

	public static void main(String[] args) {
		String a="Army";
		String b="Girl";
		boolean c= a.equals(b);
		System.out.println(c);

	}

}
