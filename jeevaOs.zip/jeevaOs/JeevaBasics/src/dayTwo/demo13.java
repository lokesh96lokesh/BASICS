package dayTwo;

public class demo13 {
	public static void main(String args[]) {
		String a[]= {"world","wide","wonder"};
		System.out.println(a[0].length());
		System.out.println(a[1].length());
		System.out.println(a[2].length());
		System.out.println(a[0].toUpperCase());
		System.out.println(a[1].toUpperCase());
		System.out.println(a[2].toUpperCase());
		String b="programs";
		String c=b.concat(a[0]);
		System.out.println(c);
		
		
		
	}

}
