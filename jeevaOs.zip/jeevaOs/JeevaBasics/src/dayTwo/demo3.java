package dayTwo;

public class demo3 {
	public static void main(String args[]) {
		String a="soft";
		boolean b= a.endsWith("v");
		System.out.println(b);
	}
}
