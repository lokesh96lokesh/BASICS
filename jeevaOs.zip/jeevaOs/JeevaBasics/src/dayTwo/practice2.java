package dayTwo;

public class practice2 {

	public static void main(String[] args) {
		int a[]= {10,20,03,40,32};
		System.out.println(a[2]);
		String b[]= {"jeeva","thiru","dinesh","surya"};
		System.out.println(b[0]+" "+b[1]);
		char c[]= {'J','S','V','N'};
		System.out.println(c[1]);
		
		
		char ch=66;
		System.out.println(ch);

	}

}
