package dayTwo;

public class practice3 {

	public static void main(String[] args) {
		String a="java";
		char []b= a.toCharArray();
		//System.out.println(b[2]);
		
		String c="jeva";
		String []d= c.split("e");
		System.out.println(d[1]);
		
//		int num []= {10,20,38,32,21};
//		System.out.println(num[4]);
		
		String []one= {"jeeva","java","python"};
		System.out.println(one[1]);

	}

}
