package dayTwo;

public class car {
		String brand;
		String model;
		long price;
		boolean isPetrol;
}
