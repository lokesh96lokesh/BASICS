package dayTwo;

public class demo2 {
	public static void main(String args[]) {
		String a= "HELLO java";
		System.out.println(a.toLowerCase());
		System.out.println(a.length());
	}

}
