package dayTwo;

public class demo9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a= "Fantasy program";
		boolean b= a.startsWith("F");
		boolean c= a.endsWith("s");
		System.out.println(b);
		System.out.println(c);
		System.out.println(a.length());
		System.out.println(a.charAt(a.length()-2));

	}

}