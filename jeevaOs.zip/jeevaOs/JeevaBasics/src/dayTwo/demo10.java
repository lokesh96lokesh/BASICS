package dayTwo;

public class demo10 {
	String brand;
	String model;
	long price;
	boolean isPetrol;
}

