package practice;

public class RemoveDuplicates {
	    public static void main(String[] args) {
	        int nums[] = {1, 2, 2, 3, 4, 4};

	        for (int i = 0; i < nums.length; i++) {
	            boolean isDuplicate = false;

	            // Check if nums[i] appeared before in the array
	            for (int j = 0; j < i; j++) {
	                if (nums[i] == nums[j]) {
	                    isDuplicate = true;
	                    break;
	                }
	            }

	            // Print only if it has not appeared before
	            if (!isDuplicate) {
	                System.out.print(nums[i] + " ");
	            }
	        }
	    }
	}



