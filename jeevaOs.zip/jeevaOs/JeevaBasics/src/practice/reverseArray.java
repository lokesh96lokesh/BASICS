package practice;

public class reverseArray {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50};
		int[] b=new int[a.length];
		for(int i=a.length-1,n=0;i>=0;i--,n++) {
			b[n]=a[i];
			System.out.println(b[n]);
		}

	}

}
