package practice;

public class removeSecondInt {
//REMOVE THE THIRD INTEGER VALUE OF GIVEN ARRAY
	public static void main(String[] args) {
		String a="abcde123456";
		char[] b=a.toCharArray();
		//boolean c=true;
		String rev=" ";
		int count=0;
		for(int i=0;i<b.length;i++) {
			if(b[i]>='0'&&b[i]<='9') { 
				count++;
				if(count==6) {
					continue;
				}
			}
		rev=rev+b[i];
		}
		
		System.out.println(rev);
	}

}
