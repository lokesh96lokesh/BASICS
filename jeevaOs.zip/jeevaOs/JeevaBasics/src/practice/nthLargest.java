package practice;

import java.util.Scanner;

public class nthLargest {
	static Scanner s= new Scanner(System.in);
	public static void main(String[] args) {
		int a[]= {10,30,40,20,56,79,8,35};
		System.out.println("Enter  which largest you want: ");
		int n=s.nextInt();
		if (n > a.length || n <= 0) {
            System.out.println("Invalid value for n.");
            return;
        }
		int largest=0;
		for(int i=1;i<=n;i++) {
			largest=Integer.MIN_VALUE;
			int index=-1;
			for(int j=0;j<a.length;j++) {
				if(a[i]>largest) {
					largest=a[i];
					index=j;
				}
			}
			if (index != -1) {
                a[index] = Integer.MIN_VALUE;
            }
		}
		System.out.println(largest);
	}
}
