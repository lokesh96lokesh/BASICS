package practice;

public class StringarraySorting {

	public static void main(String[] args) {
		String a[]= {"jeevan","thiru","suri"};
		String b=a[0];
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i].length()<a[j].length()) {
					b=a[i];
					a[i]=a[j];
					a[j]=b;
				}
			}
			System.out.println(a[i]);
		}

	}

}
