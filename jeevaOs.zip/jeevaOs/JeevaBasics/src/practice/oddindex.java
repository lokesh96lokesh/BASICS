package practice;

public class oddindex {

	public static void main(String[] args) {
		int a[]= {36,432,13,65,80};
		for(int i=0;i<a.length;i++) {
			if(a[i]%2!=0)
				System.out.println(a[i]);
		}

	}

}
