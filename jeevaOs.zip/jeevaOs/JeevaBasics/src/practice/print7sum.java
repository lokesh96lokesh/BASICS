package practice;

public class print7sum {

	public static void main(String[] args) {
		int a[]= {2,5,6,1,8,9};
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]+a[j]==7)
					System.out.println(a[i]+"+"+a[j]);
			}
		}
		

	}

}
