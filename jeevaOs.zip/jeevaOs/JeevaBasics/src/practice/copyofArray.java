package practice;

public class copyofArray {

	public static void main(String[] args) {
		int a[]= {10,34,43,65};
		int b[]=new int[a.length];
		for(int i=0;i<a.length;i++) {
			b[i]=a[i];
			System.out.println(a[i]);
			System.out.println(b[i]);
		}


	}

}
