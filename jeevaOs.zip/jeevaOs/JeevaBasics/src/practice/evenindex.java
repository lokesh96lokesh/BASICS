package practice;

public class evenindex {

	public static void main(String[] args) {
		int a[]= {2,3,45,67,80};
		for(int i=0;i<a.length;i++) {
			if(a[i]%2==0)
				System.out.println(a[i]);
		}

	}

}
