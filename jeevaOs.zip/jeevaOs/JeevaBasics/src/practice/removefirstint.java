package practice;

public class removefirstint {

	public static void main(String[] args) {
		String a="abc123def";
		
		
		
		

	}

}
