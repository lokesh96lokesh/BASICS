package practice;

public class reverseString {

	public static void main(String[] args) {
		String a="I,am,a,developer";
		String b[]=a.split(",");
		String res="";
		for(int i=0;i<b.length;i++) {
			String rev="";
			for(int j=b[i].length()-1;j>=0;j--) {
				rev=rev+b[i].charAt(j);
			}
			res+=rev;
			if(i<b.length-1)
				res+=",";
		}
		System.out.println(res);
	}

}
