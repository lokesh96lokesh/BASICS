package practice;

public class arm {

	public static void main(String[] args) {
		for(int i=150;i<=180;i++) {
		int a=i;
		int temp=0;
		int store=a;
		while(a>0) {
			int b=a%10;
			int cube=b*b*b;
			 temp=cube+temp;
			 a=a/10;
		}
		
		if(store==temp)
			System.out.println(temp);
		}
	}

}
