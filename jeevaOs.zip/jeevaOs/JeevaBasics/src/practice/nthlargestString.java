package practice;

import java.util.Scanner;

public class nthlargestString {
	static Scanner s= new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the N th largest: ");
		String a[]= {"jeevan","manoj","thir"};
		int n=2;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i].length()<a[j].length()) {
					String b=a[i];
					a[i]=a[j];
					a[j]=b;
				}
			}
		}
		System.out.println(a[n-1]);
	}

}
