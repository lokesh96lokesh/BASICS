package practice;

public class armstrong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 150-180
//		int a=150;
//		int b=180;
		for(int i=150;i<=180;i++) {
			int a=i;
			int store=a;
			int temp=0;
			while(a>0) {
				int c=a%10;
				int cube=c*c*c;
				temp=cube+temp;
				a=a/10;
			}
			if(store ==temp)
				System.out.println(temp);
		}
	}

}
