package practice;

public class demo {
	public static void main(String[] args) {
		String a="hello";
		String b=new String("hello");
		System.out.println((b));
	}
}
