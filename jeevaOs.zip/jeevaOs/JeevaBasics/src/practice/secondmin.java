package practice;

public class secondmin {

	public static void main(String[] args) {
		int a[]= {4,3,7,8,1};
		int n=2;
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
			  if(a[i]>a[j]) {
				int b=a[i];
				a[i]=a[j];
				a[j]=b;
			  }
			}	
		}
		System.out.println(a[n-1]);

	}

}
