package practice;

public class palindrome {
	public static void main(String args[]) {
		
		for(int i=101;i<=999;i++) {
			int a=i;
			int temp=0;
			int orgs=i;
			while(a>0) {
				int b=a%10;
				temp=(temp*10)+b;
				a/=10;
			}
			if(temp==orgs)
				System.out.println(orgs);
		}
	}

}
