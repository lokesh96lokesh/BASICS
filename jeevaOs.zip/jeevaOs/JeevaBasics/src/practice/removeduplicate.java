package practice;

////Error programe
//	public static void main(String[] args) {
//		int nums[]= {2,3,4,5,3,4,7,8,6,4,3};
//		for(int i=0;i<nums.length;i++) {
//			for(int j=i+1;j<nums.length;j++) {
//				if(nums[i]==nums[j]) {
//					nums[j]=-1;
//					nums[i]=-1;
//				}
//			}
//			if(nums[i]!=-1)
//				System.out.println(nums[i]);
//			
//		}
//}
public class removeduplicate {
    public static void main(String[] args) {
        //int nums[] = {2, 3, 4, 5, 3, 4, 7, 8, 6, 4, 3};
    	int nums[]= {1,2,2,3,4,4};

        for (int i = 0; i < nums.length; i++) {
            int count = 0;
            for (int j = 0; j < nums.length; j++) {
                if (nums[i] == nums[j]) {
                    count++;
                }
            }
            if (count == 1) {
                System.out.println(nums[i]);
            }
        }
    }
}

	
	
	



