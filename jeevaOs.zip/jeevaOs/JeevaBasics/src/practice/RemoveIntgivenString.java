package practice;

public class RemoveIntgivenString {

	public static void main(String[] args) {
		String a="abcd123efg";
		char[] b=a.toCharArray();
		boolean c=true;
		String rev=" ";
		for(int i=0;i<b.length;i++) {
			if(b[i]>='0'&&b[i]<='9'&&c==true) {
				c=false;
			//System.out.println(b[i]);
			}else
				rev=b[i]+rev;
		}
		System.out.println(rev);

	}

}
