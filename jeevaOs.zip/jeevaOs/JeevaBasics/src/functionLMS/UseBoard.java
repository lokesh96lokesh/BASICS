package functionLMS;

class Board {
	public void write(String name) {
		System.out.println(name);
	}
}

public class UseBoard {
	public static void main(String[] args) {
		Board b=new Board();
		b.write("smoothly");

	}

	

}
