package dayThree;

public class UseTelephone {

	public static void main(String[] args) {
		Telephone phone1= new Telephone();
		Telephone phone2= new Telephone();
		Telephone phone3= new Telephone();
		
		

	}

}
