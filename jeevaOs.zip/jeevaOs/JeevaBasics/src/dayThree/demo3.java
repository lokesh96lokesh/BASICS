package dayThree;

public class demo3 {

	public static void main(String[] args) {
		String a= args[0];    //jeeva,nandham
		String []b=a.split(",");
		System.out.println(b[0].concat(b[1]));

	}

}
