package dayThree;

public class demo1 {

	public static void main(String ars[]) {
		String a= ars [0];
		String b= ars [1];
		String c= a.toUpperCase()+ " "+b.toLowerCase();
		System.out.println(c);


	}

}
