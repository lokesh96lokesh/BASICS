package dayThree;

public class demo5 {
	public static void main(String args[]) {
		String a=args[0];
		//float b=Float.parseFloat(a);
		long b= Long.parseLong(a);
		System.out.print(b);
	}

}
