package dayThree;

public class Telephone {
	String brand;
	int price;
	String color;
	boolean isWireless;

}
