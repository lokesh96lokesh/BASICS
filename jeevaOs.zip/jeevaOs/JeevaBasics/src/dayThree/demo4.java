package dayThree;

public class demo4 {

	public static void main(String[] args) {
		//ragul,22,93.5,true
		
		String a=args[0];
		String b[]=a.split(",");
		System.out.println("Name =".concat(b[0])+"age ="+b[1]+"mark ="+b[2]+"result ="+b[3]);

	}

}
