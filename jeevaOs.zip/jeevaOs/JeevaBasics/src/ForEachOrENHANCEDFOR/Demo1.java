package ForEachOrENHANCEDFOR;

public class Demo1 {

	public static void main(String[] args) {
		int b[]= {10,20,30,40,50};
		for(int num:b) {
			System.out.println(num);
		}

	}

}
