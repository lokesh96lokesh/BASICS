package Function;

public class max {
	

	public static void main(String[] args) {
		System.out.println(max(10,20,30));

	}
	public static int max(int a,int b,int c) {
		int max=0;
		if(a>b&&a>c)
			return a+max;
		if(b>a&&b>c)
			return b+max;
		if(c>a&&c>b)
			return c+max;
		return max;
		
	}
	public int min(int a,int b,int c) {
		int min=0;
		if(a<b&&a<c)
			return a+min;
		if(b<a&&b<c)
			return b+min;
		if(c<a&&c<b)
			return c+min;
		return min;
		
	}

}
