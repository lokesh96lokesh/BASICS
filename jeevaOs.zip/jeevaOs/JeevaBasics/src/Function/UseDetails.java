package Function;

public class UseDetails {
	
	public static void name(String name) {
		System.out.println(name);
	}
	public static void age() {
		System.out.println("23");
	}
	public String qualification(String qualify) {
		return qualify;
	}
	public static int pasedout() {
		return 2021;
	}


	public static void main(String[] args) {
		//details d=new details();
		name("jeeva");
		age();
		System.out.println("BCA");
		System.out.println(pasedout());
	}
}

//class details {
//	}
