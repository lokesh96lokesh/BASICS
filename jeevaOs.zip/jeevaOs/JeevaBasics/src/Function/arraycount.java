package Function;

class total {
	public int getcount(int a[]) {
		int total=0;
		for(int i=0;i<a.length;i++) {
			total=total+a[i];
		}
		return total;
	}
}


public class arraycount {

	public static void main(String[] args) {
		total t= new total();
		int a[]= {10,20,30,40};
		System.out.println(t.getcount(a));

	}

}

