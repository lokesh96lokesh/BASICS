package Function;
class Car {
	String brand;
	String color;
	int price;
	boolean isWarranty;
	public void printcar(Car[]c) {
//		for(int i=0;i<c.length;i++) {
//			System.out.println(c[i].brand+" "+c[i].color+" "+c[i].price+" "+c[i].isWarranty);
//		}
		System.out.println(c[0].brand+" "+c[0].color+" "+c[0].price+" "+c[0].isWarranty);
	}
}
public class UseCar {
	public static void main(String[] args) {
		Car car1 = new Car();
		Car car2 = new Car();
		Car car3 = new Car();
		car1.brand="Hundai";
		car2.brand="audi";
		car3.brand="honda";
		car1.color="white";
		car2.color="red";
		car3.color="blue";
		car1.price=20000;
		car2.price=20500;
		car3.price=25600;
		car1.isWarranty=true;
		car2.isWarranty=false;
		car3.isWarranty=true;
		Car c[]= {car1,car2,car3};
		car1.printcar(c);
	}
}
