package Function;

 class calc {
	public void addition(int a,int b) {
		System.out.println(a+b);
	}
	public int subtraction(int a,int b) {
		return a-b;
	}
	public int multiply(int a,int b) {
		return a*b;
	}
	public int divide(int a,int b) {
		return a/b;
	}
}

public class calculator {
	public static void main(String args[]) {
		calc details=new calc();
		details.addition(10, 20);
		System.out.println(details.subtraction(200,20));
		System.out.println(details.multiply(30, 5));
		System.out.println(details.divide(5, 50));
	}
}
