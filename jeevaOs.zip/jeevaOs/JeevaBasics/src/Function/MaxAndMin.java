package Function;

class finding {
	public int max(int a,int b,int c) {
		if(a>b&&a>c)
			return a;
		else if(b>a&&b>c)
			return b;
		else
			return c;
		
	}
	public int min(int a,int b,int c) {
		int min=0;
		if(a<b&&a<c)
			return a+min;
		if(b<a&&b<c)
			return b+min;
		if(c<a&&c<b)
			return c+min;
		return min;
		
	}
}
public class MaxAndMin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		finding details = new finding();
		System.out.println("Max value of:"+details.max(10,20,30));
		System.out.println("Min value of:"+details.min(20,10,4));
		

	}

}
