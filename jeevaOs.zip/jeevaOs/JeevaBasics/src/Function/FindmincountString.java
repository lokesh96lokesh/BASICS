package Function;

public class FindmincountString {
	public static void main(String[] args) {
		count a= new count();
		String value[]= {"moon","earth","sun"};
		System.out.println(a.getmin(value));
	}

}

class count {
	public String getmin(String value[]) {
		String min=value[0];
		for(int i=0;i<value.length;i++) {
			if(value[i].length()<min.length())
				min=value[i];
		}
		return min;
	}
	
}
