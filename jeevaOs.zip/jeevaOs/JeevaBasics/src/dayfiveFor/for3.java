package dayfiveFor;

public class for3 {

	public static void main(String[] args) {
		String a="COMMUNICATION";
		char b[]=a.toCharArray();
		for(int i=0;i<b.length;i++) {
			System.out.println(b[i]);
		}

	}

}
