package dayfiveFor;

public class fibonacci {

	public static void main(String[] args) {
		int num1=0;
		int num2=1;
		int num3=0;
		for(int i=num1;i<6;i++) {
			num3=num1+num2;
			System.out.println(num1);
			num1=num2;
			num2=num3;
		}
			
			


	}

}
