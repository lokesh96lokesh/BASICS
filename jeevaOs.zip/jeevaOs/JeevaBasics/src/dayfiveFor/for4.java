package dayfiveFor;

public class for4 {

	public static void main(String[] args) {
		String a="COMMUNICATION";
		for(int i=0;i<a.length();i++)
			System.out.println(a.charAt(i));
		

	}

}
