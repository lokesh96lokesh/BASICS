package dayfiveFor;

public class square {

	public static void main(String[] args) {
		int a=10;
		for(int i=1;i<=a;i++) {
			System.out.println(i*i);
		}
		

	}

}
