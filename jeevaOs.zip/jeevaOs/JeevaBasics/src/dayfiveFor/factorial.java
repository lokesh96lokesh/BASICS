package dayfiveFor;

public class factorial {

	public static void main(String[] args) {
		int a=10;
		for(int i=1;i<=a;i++) {
			if(i%2==0)
				System.out.println(i);
		}

	}

}
