package dayfiveFor;

public class for5 {
	public static void main(String args[]) {
		String a ="COMMUNICATION";
		for (int i=a.length()-1;i>=0;i--)
			System.out.println(a.charAt(i));
				
	}

}
