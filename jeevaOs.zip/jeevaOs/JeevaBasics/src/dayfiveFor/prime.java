package dayfiveFor;

public class prime {

	public static void main(String[] args) {
		boolean isprime= true;
		int a=7;
		for(int i=2;i<a;i++)
		{
			if(a%i==0)
				isprime=false;
		}
		if(isprime) {
			System.out.println("prime number");
		}
		else
			System.out.println("not a prime number");
			
		

	}

}
