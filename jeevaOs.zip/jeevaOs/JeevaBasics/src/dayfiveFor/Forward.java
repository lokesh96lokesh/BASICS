package dayfiveFor;

import java.util.Iterator;

public class Forward {
	public static void main(String args[]) {
		int nim = 5;
		for (int i = 1; i <=nim; i++) {
			
			System.out.println(i);
		}
	}

}
