package dayOne;

public class UseEmployee {

	public static void main(String[] args) {
		Employeeclass empdetails1= new Employeeclass();
		Employeeclass empdetails2= new Employeeclass();
		 
		empdetails1.employeeId= 101;
		empdetails2.employeeId= 102;
		
		empdetails1.employeeName="jeeva";
		empdetails2.employeeName="raza";
		
		empdetails1.dateOfBirth="10-02-2001";
		empdetails2.dateOfBirth="12-12-2002";
		
		empdetails1.mobileNo= 984539845l;
		empdetails2.mobileNo= 895339245l;
		
		System.out.println(empdetails1.employeeId);
		System.out.println(empdetails1.employeeName);
		System.out.println(empdetails1.dateOfBirth);
		System.out.println("+91" + " "+empdetails1.mobileNo);
		System.out.println();
		
		System.out.println(empdetails2.employeeId);
		System.out.println(empdetails2.employeeName);
		System.out.println(empdetails2.dateOfBirth);
		System.out.println("+91" + " "+empdetails2.mobileNo);
		

	}

}
