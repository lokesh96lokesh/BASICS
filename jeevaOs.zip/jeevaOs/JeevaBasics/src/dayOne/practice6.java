package dayOne;

public class practice6 {

	public static void main(String[] args) {
		int a= 42;
		int b=22;
		float result = a+b;
		System.out.println(result/2);

	}

}
