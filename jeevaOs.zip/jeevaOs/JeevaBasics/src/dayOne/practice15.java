package dayOne;

public class practice15 {
	public static void main(String args[]) {
		float celsius=1f;
		float Fahrenheit =(celsius*(9/5)+32f);
		System.out.println(Fahrenheit);
	}

}
