package dayOne;

public class practice5 {

	public static void main(String[] args) {
		int radius=8;
		float circle =3.14f* radius * radius;
		System.out.println(circle);
	}

}
