package dayOne;

public class car {
	String brand;
	int price;
	int taxpercentage;
	int taxprice;
	int netprice;
	boolean isAirbag;
}
