package dayOne;

public class practice25 {

	public static void main(String[] args) {
		String studentName1= "jeeva";
		String studentName2= "raza";
		int rollNumber1=101;
		int rollNumber2=202;
		
		System.out.println("studentName:"+studentName1 +"-"+"rollno:"+rollNumber1);
		System.out.println("studentName:"+studentName2 +"-"+"rollno:"+rollNumber2);

	}

}
