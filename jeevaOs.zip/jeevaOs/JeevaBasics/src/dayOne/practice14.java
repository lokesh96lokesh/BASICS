package dayOne;

public class practice14 {
	public static void main(String args[]) {
		int one =10;
		int two =32;
		int three =41;
		int result =one*two+three;
		System.out.println(result);
	}
}
