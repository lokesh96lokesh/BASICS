package dayOne;

public class practice11 {
	public static void main(String arg[]) {
		int father_age=45;
		int son_age= 23;
		int result= father_age-son_age;
		System.out.println(result);
	}

}
