package dayOne;

public class practice8 {

	public static void main(String[] args) {
		int age1= 18;
		int age2= 19;
		int age3= 17;
		int age4= 15;
		if(age1<18) {
			System.out.println("age1 is minor the age is:"+age1);
		}
		else if (age2<18) {
			System.out.println("age2 is minor the age is:"+age2);

		}
		else if (age3<18) {
			System.out.println("age3 is minor the age is:"+age3);

		}
		else if (age4<18) {
			System.out.println("age4 is minor the age is:"+age4);

		}
	}

}
