package dayOne;

public class Marker {
	int price;
	String colour;
	double weight;
	String isQuality;
}
