package dayOne;

public class practice19 {
	public static void main(String args[]) {
		System.out.println("\"Onesoft Technologies\"");
		System.out.println("\"is the good place to\"");
		System.out.println("\"learn java\"");
	}

}
