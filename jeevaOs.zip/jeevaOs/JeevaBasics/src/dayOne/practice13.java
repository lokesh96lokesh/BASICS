package dayOne;

public class practice13 {
	public static void main(String args[]) {
		char a= 'j';
		char b= 's';
		
		System.out.print(a +" "+ b);
	}

}
