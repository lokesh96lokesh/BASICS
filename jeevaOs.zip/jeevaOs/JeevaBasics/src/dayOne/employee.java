package dayOne;

public class employee {
	String name;
	int id;
	int age;
	int salary;
	boolean ismale;

}
