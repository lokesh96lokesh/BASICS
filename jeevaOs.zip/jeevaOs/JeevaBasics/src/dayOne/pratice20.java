package dayOne;

public class pratice20 {
	public static void main(String args[]) {
		String a="jeeva";
		String b= "naveen";
		System.out.println(a+b);
		
	}

}
