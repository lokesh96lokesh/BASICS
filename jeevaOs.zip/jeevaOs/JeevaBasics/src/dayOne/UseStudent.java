package dayOne;

public class UseStudent {

	public static void main(String[] args) {
		 student stu_details1= new student();
		 student stu_details2= new student();
		 student stu_details3= new student();
		 
		 stu_details1.name="siva";
		 stu_details2.name="mari";
		 stu_details3.name="valli";
		 
		 stu_details1.id= 234;
		 stu_details2.id= 236;
		 stu_details3.id= 237;
		 
		 stu_details1.age=14;
		 stu_details2.age=15;
		 stu_details3.age=13;
		 
		 stu_details1.stu_class=9;
		 stu_details2.stu_class=10;
		 stu_details3.stu_class=8;
		 
		 stu_details1.attendence_Percentage=75;
		 stu_details2.attendence_Percentage=80;
		 stu_details3.attendence_Percentage=90;
		 
		 stu_details1.no_of_days_present = stu_details1.Workingdays*stu_details1.attendence_Percentage/100;
		 System.out.println( stu_details1.no_of_days_present);
		 
		 stu_details2.no_of_days_present = stu_details2.Workingdays*stu_details2.attendence_Percentage/100;
		 System.out.println(stu_details2.no_of_days_present);
		 
		 stu_details3.no_of_days_present = stu_details3.Workingdays*stu_details3.attendence_Percentage/100;
		 System.out.println(stu_details3.no_of_days_present);



	}

}
