package dayOne;

public class datatypes {

	public static void main(String[] args) {
		String name="jeeva";
		int age = 23;
		float height = 5.7f;
		double weight = 53.52d;
		long ph_No = 6379148896l;
		char inistial = 'M';
		boolean isMale = true;
		
		System.out.print(name +" "+ age +" "+height +" " +weight +" "+ inistial);
	}

}
