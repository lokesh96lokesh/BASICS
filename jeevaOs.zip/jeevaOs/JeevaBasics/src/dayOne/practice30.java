package dayOne;

public class practice30 {

	public static void main(String[] args) {
		int input=20;
		
		if(input%2==0) {
			System.out.println("The given input is equal to zero");
		}else
			System.out.println("the given input is not equal to zero");

	}

}
