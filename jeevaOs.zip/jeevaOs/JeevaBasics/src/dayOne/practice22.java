package dayOne;

public class practice22 {

	public static void main(String[] args) {
		float a =4.8f;
		float b =3.3f;
		float c =5.7f;
		
		System.out.println(a+b+c);
	}

}
