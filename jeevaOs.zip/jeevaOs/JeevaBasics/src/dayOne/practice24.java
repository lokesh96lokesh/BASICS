package dayOne;

public class practice24 {
	public static void main(String[] args) {
		String nameOfStudent="jeeva";
		long studentMobileNumber = 6379148373l;
		System.out.println(nameOfStudent+" "+studentMobileNumber);
	}

}
