package dayOne;

public class cardetails {
	public static void main(String args[]) {
		car pricedetails = new car();
		pricedetails.brand="Hundai";
		pricedetails.price =183540;
		pricedetails.taxpercentage = 3;
		pricedetails.taxprice = pricedetails.price * pricedetails.taxpercentage/100;
		pricedetails.netprice = pricedetails.taxprice * pricedetails.price;
		
		System.out.println("carBrand:"+pricedetails.brand);
		System.out.println();
		System.out.println("percentage:"+pricedetails.taxpercentage);
		System.out.println("taxprice:"+ pricedetails.taxprice);
		System.out.println("netprice:"+ pricedetails.netprice);
	}

}
