package dayOne;

public class employeeDetails {

	public static void main(String[] args) {
		employee e1= new employee();
		employee e2= new employee();
		e1.name ="jeeva";
		e1.age=23;
		e1.id=7;
		e1.salary=200000;
		e1.ismale=true;
		System.out.println(e1.name);
		System.out.println(e1.age);
		System.out.println(e1.id);
		System.out.println(e1.salary);
		System.out.println(e1.ismale);
		e2.name="abc";
		
		
	}

}
