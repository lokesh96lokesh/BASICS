package dayOne;

public class practice12 {
	public static void main(String aw[]) {
		float stu1= 57.3f;
		int stu2=53;
		float result= stu1-stu2;
		System.out.println("different:"+ result);
	}

}
