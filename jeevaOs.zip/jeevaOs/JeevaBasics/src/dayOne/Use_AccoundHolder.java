package dayOne;

public class Use_AccoundHolder {

	public static void main(String[] args) {
		AccountHolder details1= new AccountHolder();
		AccountHolder details2= new AccountHolder();
		AccountHolder details3= new AccountHolder();
		
		details1.name="mano";
		details2.name="savithri";
		details3.name="kamban";
		
		details1.age = 26;
		details2.age = 25;
		details3.age = 30;
		
		details1.gender= "male";
		details2.gender= "Female";
		details3.gender= "male";
		
		details1.AccountNumber=28330485612583l;
		details2.AccountNumber=28330485612584l;
		details3.AccountNumber=28330485612585l;
		
		details1.monthlyincom=21000;
		details2.monthlyincom=20000;
		details3.monthlyincom=31000;
		
		details1.savingPercentage=18;
		details2.savingPercentage=20;
		details3.savingPercentage=10;
		
		details1.SavingsAmount = details1.monthlyincom*details1.savingPercentage/100;
		System.out.println(details1.SavingsAmount);
		
		details2.SavingsAmount = details2.monthlyincom*details2.savingPercentage/100;
		System.out.println(details2.SavingsAmount);
		
		details3.SavingsAmount = details3.monthlyincom*details3.savingPercentage/100;
		System.out.println(details3.SavingsAmount);


		
		
		

	}

}
