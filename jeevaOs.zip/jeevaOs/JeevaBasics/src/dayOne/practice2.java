package dayOne;

public class practice2 {
	public static void main (String args[]) {
		float a= 5.2f;
		float b= 7.4f;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		
	}
}
