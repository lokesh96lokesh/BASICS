package dayOne;

public class UseAirConditioner {

	public static void main(String[] args) {
		AirConditioner conditioner1= new AirConditioner();
		AirConditioner conditioner2= new AirConditioner();
		
		conditioner1.brand="TATA";
		conditioner1.price=30000;
		conditioner1.noOfWings=4;
		conditioner1.isQuality="good";
		
		conditioner2.brand="Haier";
		conditioner2.price=70000;
		conditioner2.noOfWings=5;
		conditioner2.isQuality="good";
		
		System.out.println("AirCOnditioner Brand is: "+conditioner1.brand);
		System.out.println("AirCOnditioner price is: "+conditioner1.price);
		System.out.println("AirCOnditioner wings is: "+conditioner1.noOfWings);
		System.out.println("AirCOnditioner Qulality : "+conditioner1.isQuality);
		System.out.println();
		System.out.println("AirCOnditioner Brand is: "+conditioner2.brand);
		System.out.println("AirCOnditioner price is: "+conditioner2.price);
		System.out.println("AirCOnditioner wings is: "+conditioner2.noOfWings);
		System.out.println("AirCOnditioner Qulality : "+conditioner2.isQuality);


	}

}
