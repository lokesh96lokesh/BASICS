package dayOne;

public class opertors {
	public static void main(String args[]) {
		int num1= 25;
		int num2= 3;
		int sum = num1+num2;
		int sum2 = num1-num2;
		System.out.println(sum);
		System.out.println(sum2);
		System.out.println(num1 * num2);
		System.out.println(num1 / num2);
		System.out.println(num1 % num2);
		System.out.println(num1 < num2);
		System.out.println(num1 > num2);
	}
}
