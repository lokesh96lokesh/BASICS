package dayOne;

public class practice17 {
	public static void main(String args[]) {
		int a=23;
		int b= 43;
		int result = (a+b)*(a+b);
		System.out.println(result);
	}

}
