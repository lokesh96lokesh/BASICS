package dayOne;

public class UsePen {

	public static void main(String[] args) {
		pen penDetails1 = new pen();
		penDetails1 .brand="cello";
		penDetails1.isBlueColor=true;
		penDetails1.price=25;
		penDetails1.tipWidth=1;
		
		pen penDetails2 = new pen();
		penDetails2 .brand ="absara";
		penDetails2 .isBlueColor=false;
		penDetails2 .price=30;
		penDetails2 .tipWidth=1.5f;
		
		pen penDetails3 = new pen();
		penDetails3 .brand ="greenPen";
		penDetails3 .isBlueColor= false;
		penDetails3 .price=32;
		penDetails3 .tipWidth = 2.05f;
		
		int average = penDetails1.price+ penDetails2.price + penDetails3.price;
		System.out.println("price:"+ average);
		

	}

}
