package dayOne;

public class PrintingState {
	

}
