package dayOne;

public class practice23 {

	public static void main(String[] args) {
		String stu_name="jeeva";
		String initial="M";
		System.out.println(stu_name+" "+initial);
	}

}
