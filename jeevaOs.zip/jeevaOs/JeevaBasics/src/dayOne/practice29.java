package dayOne;

public class practice29 {
	public static void main(String args[]) {
		String myname="jeeva";
		String f_name="mahendiran";
		
		System.out.println(myname+" "+f_name);
	}
}
