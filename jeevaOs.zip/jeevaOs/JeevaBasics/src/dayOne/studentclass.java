package dayOne;

public class studentclass {
	String studentName;
	int studentAge;
	long StudentMobileNo;
	char classSection;
	int marksPercentage;

}
