package dayOne;

public class practice28 {

	public static void main(String[] args) {
		int input=16;
		
		System.out.println(input*input);

	}

}
