package dayOne;

public class AccountHolder {
	String name;
	int age;
	String gender;
	long AccountNumber;
	int monthlyincom;
	int savingPercentage;
	int SavingsAmount;
}
