package dayOne;

public class Employeeclass {
	 int employeeId;
	 String employeeName;
	 String dateOfBirth;
	 long mobileNo;

}
