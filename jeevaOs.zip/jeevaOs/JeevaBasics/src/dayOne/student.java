package dayOne;

public class student {
		String name;
		int id;
		int age;
		int stu_class;
		int attendence_Percentage;
		int no_of_days_present;
		int Workingdays = 240;
		
}
