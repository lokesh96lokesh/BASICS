package dayOne;

public class practice7 {

	public static void main(String[] args) {
		float a=123.4f;
		float b= 27.78f;
		float product = a*b;
		System.out.println(product);
	}

}
