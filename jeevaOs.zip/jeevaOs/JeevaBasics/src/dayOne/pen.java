package dayOne;

public class pen {
	String brand;
	int price;
	boolean isBlueColor;
	float tipWidth;
	
}
