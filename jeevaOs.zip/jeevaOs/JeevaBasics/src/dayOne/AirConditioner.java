package dayOne;

public class AirConditioner {
	
	String brand;
	int price;
	int noOfWings;
	String isQuality;

}
