package dayOne;

public class practice3 {
	public static void main(String args[]) {
		double a= 3.5d;
		double b= 4.8d;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
	}
}
