package dayOne;

public class practice9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 21;
		int b= 23;
		int c= 45;
		
		System.out.println("A cube is:"+ a*a*a);
		System.out.println("b cube is:"+ b*b*b);
		System.out.println("c cube is:"+ c*c*c);

	}

}
