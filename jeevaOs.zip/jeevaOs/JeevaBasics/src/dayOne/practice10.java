package dayOne;

public class practice10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age1=23;
		int age2=13;
		int age3=21;
		int age4=34;
		int age5=61;
		System.out.println(age1+age2+age3+age4+age5);
		

	}

}
