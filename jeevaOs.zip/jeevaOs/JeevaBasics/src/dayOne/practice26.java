package dayOne;

public class practice26 {	
	public static void main(String args[]) {
		String personName="jeeva";
		int height = 6;
		float weight = 53.4f;
		float BMI=weight/height*height;
		System.out.println("personName:"+personName +" "+ "BMIvalue:"+BMI);
	}
}
