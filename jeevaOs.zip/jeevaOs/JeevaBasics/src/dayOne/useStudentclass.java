package dayOne;

public class useStudentclass {

	public static void main(String[] args) {
		studentclass stu_details1 = new studentclass();
		studentclass stu_details2 = new studentclass();
		studentclass stu_details3 = new studentclass();
		
		stu_details1.studentName="jeeva";
		stu_details2.studentName="raza";
		stu_details3.studentName="kadhar";
		
		stu_details1.studentAge=24;
		stu_details2.studentAge=22;
		stu_details3.studentAge=23;
		
		stu_details1.StudentMobileNo=9896423713l;
		stu_details2.StudentMobileNo=98922353l;
		stu_details2.StudentMobileNo=3877264713l;
		
		stu_details1.classSection='A';
		stu_details2.classSection='B';
		stu_details3.classSection='C';
		
		stu_details1.marksPercentage=70;
		stu_details2.marksPercentage=73;
		stu_details3.marksPercentage=75;
		
		
		System.out.println("StudentName:"+stu_details1.studentName);
		System.out.println("StudentAge:"+stu_details1.studentAge);
		System.out.println("StudentMobileNo:"+stu_details1.StudentMobileNo);
		System.out.println("Section:"+stu_details1.classSection);
		System.out.println("PercentageOfMark:"+stu_details1.marksPercentage);
		System.out.println();
		
		System.out.println("StudentName:"+stu_details2.studentName);
		System.out.println("StudentAge:"+stu_details2.studentAge);
		System.out.println("StudentMobileNo:"+stu_details2.StudentMobileNo);
		System.out.println("Section:"+stu_details2.classSection);
		System.out.println("PercentageOfMark:"+stu_details2.marksPercentage);
		System.out.println();
		
		System.out.println("StudentName:"+stu_details3.studentName);
		System.out.println("StudentAge:"+stu_details3.studentAge);
		System.out.println("StudentMobileNo:"+stu_details3.StudentMobileNo);
		System.out.println("Section:"+stu_details3.classSection);
		System.out.println("PercentageOfMark:"+stu_details3.marksPercentage);

	}

}
