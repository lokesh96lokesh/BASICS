package dayOne;

public class practice4 {
	public static void main(String args[]) {
		long a = 8282937130l;
		long b= 32942142244l;
		System.out.println(a-b);
		
	}

}
