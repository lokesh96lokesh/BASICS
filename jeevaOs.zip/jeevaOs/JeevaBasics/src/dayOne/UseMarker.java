package dayOne;

public class UseMarker {

	public static void main(String[] args) {
		Marker marker1 = new Marker();
		Marker marker2 = new Marker();
		Marker marker3 = new Marker();
		
		marker1.price=50;
		marker1.colour= "white";
		marker1.weight= 5.2d;
		marker1.isQuality ="notbad";
		
		marker2.price=60;
		marker2.colour= "black";
		marker2.weight= 6.2d;
		marker2.isQuality ="good";
		
		marker3.price=70;
		marker3.colour= "blue";
		marker3.weight= 4.2d;
		marker3.isQuality ="good";
		
		System.out.println("Marker_Price is: "+marker1.price);
		System.out.println("Marker_colour is: "+marker1.colour);
		System.out.println("Marker_weight is: "+marker1.weight);
		System.out.println("Marker_Quality is: "+marker1.isQuality);
		
		
		

	}

}
