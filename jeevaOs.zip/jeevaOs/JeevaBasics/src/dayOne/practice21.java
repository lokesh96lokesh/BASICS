package dayOne;

public class practice21 {
	public static void main(String args[]) {
		char a='o';
		char b='n';
		char c='e';
		
		System.out.println(a+b+c);
		System.out.println(a +""+b+""+c);
		
	}

}
