package NumberGuessingGame;

import java.util.Random;
import java.util.Scanner;

public class NumberGuess {
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) {
		Random random = new Random();
		boolean playAgain;
		do {
			int lower=1;
			int upper=100;
			int GuessNo= random.nextInt(upper-lower+1)+lower;
			int attempts=0;
			System.out.println("Welocom to the Number Guessing Game!...");
	        System.out.println("I have selected a number between " + lower + " and " + upper + ". Try to guess it!");
	        //System.out.println(GuessNo);
	        while(true) {
	        	System.out.println("Enter Your Guess: ");
	        	int Guess=s.nextInt();
	        	attempts++;
	        	 if (Guess < GuessNo) 
	                 System.out.println("Too Low! Try again.");
	             else if (Guess > GuessNo) 
	                 System.out.println("Too High! Try again.");
	             else 
	                 System.out.println("Congratulations! You guessed the number in " + attempts + " attempts.");
	                 break;  
	        }
	        System.out.print("Do you want to play again? (yes/no): ");
	        String response = s.next();
	        playAgain = response.equals("yes");
		}while(playAgain);
		System.out.println("Thanks for Playing.....!");
		s.close();
	}

}
