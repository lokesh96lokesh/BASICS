package OOPS4AbstractionInterface;



 public class UseApple {
	public static void main(String[] args) {
		Apple app = new Apple();
		System.out.println(app.getName("Mango"));
		System.out.println(app.getPrice(35));
		System.out.println(app.getTaste("Sweet"));
		System.out.println(app.place("chennai"));
		Fruit a = new Apple();
		System.out.println(a.getName("Apple"));
	}
}