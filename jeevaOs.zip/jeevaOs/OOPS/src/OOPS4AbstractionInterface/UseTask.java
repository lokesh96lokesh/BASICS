package OOPS4AbstractionInterface;

public class UseTask {
	public static void main(String[] args) {
		Lion l = new Lion();
		System.out.println(l.name("Lion"));
		System.out.println(l.type("King"));
		System.out.println(l.isMale(true));
	}
}

abstract class Animal {
	public abstract String name(String name);
	public abstract String type(String Type);
	
	public String place(String place) {
		return place;
	}
	public String color(String color) {
		return color;
	}
}

class Lion extends Animal {

	@Override
	public String name(String name) {
		return name;
	}

	@Override
	public String type(String Type) {
		return Type;
	}
	public int Price(int Price) {
		return Price;
	}
	public boolean isMale(boolean isMale) {
		return isMale;
	}
	
}
