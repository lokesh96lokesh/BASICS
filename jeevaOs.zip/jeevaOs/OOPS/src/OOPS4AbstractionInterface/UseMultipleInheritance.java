package OOPS4AbstractionInterface;

public class UseMultipleInheritance {
	public static void main(String[] args) {
		c c1= new c();
		b b1= new c();
		a a1= new c();
		c1.interfaceA();
		c1.interfaceB();
		b1.interfaceB();
		a1.interfaceA();
	}
}

interface a {
	public void interfaceA();
}
interface b {
	public void interfaceB();
}
class c implements a,b {

	@Override
	public void interfaceB() {
		System.out.println("Interface B");
		
	}

	@Override
	public void interfaceA() {
		System.out.println("Interface A");
		
	}
	
}