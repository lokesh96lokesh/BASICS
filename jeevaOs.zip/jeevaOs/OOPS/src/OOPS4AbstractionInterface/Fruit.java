package OOPS4AbstractionInterface;

public interface Fruit {
	public String getName(String Name);
	public int getPrice(int Price);
	public String getTaste(String Taste);
}
class Apple implements Fruit {

	@Override
	public String getName(String Name) {
		return Name;
	}

	@Override
	public int getPrice(int Price) {
		return Price;
	}

	@Override
	public String getTaste(String Taste) {
		return Taste;
	}
	public String place(String place) {
		return place;
	}
	
}
 
