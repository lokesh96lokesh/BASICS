package OOPS4AbstractionInterface;



public class Usedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//demo d = new demo();

	}

}

abstract class demo {
	public String name(String name) {
		return name;
	}
}