package OOPS4AbstractionInterface;

public class UseVehicle {
	public static void main(String[] args) {
		vehicle v = new Bike();
		System.out.println(v.name("pulzar"));
		System.out.println(v.price(3000));
		Bike b = new Bike();
		System.out.println(b.model("2020"));
		System.out.println(b.name("apache"));
		System.out.println(b.price(4000));
		//
		//vehicle h = new vehicle();

	}
	
}

abstract class vehicle {
	public String name(String name) {
		return name;
	}
	public abstract  int price(int price);
}
class Bike extends vehicle {

	@Override
	public int price(int price) {
		return price;
	}
	public String model(String model) {
		return model;
	}
	
}