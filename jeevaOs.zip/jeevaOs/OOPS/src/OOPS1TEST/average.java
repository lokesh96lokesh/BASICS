package OOPS1TEST;

public class average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,17,40};
		boolean tele=true;
		int max=a[0];
		for(int i=0;i<a.length;i++) {
			if(a[i]>max)
				max=a[i];
		}
		System.out.println(max);

	}

}
