package OOPS1TEST;
//Class definition for Staplen
class Staplen {
 private String brand;
 int price;
 String colour;
// String material;
 boolean plastic;

 public void Brand(String brand) {
     this.brand = brand;
 }

 public void setPrice(int price) {
     this.price = price;
 }

 public void setColour(String colour) {
     this.colour = colour;
 }

// public void setMaterial(String material) {
//     this.material = material;
// }
 
 public void plastic(boolean plastic) {
	 this.plastic = plastic;
}

 public String seBrand() {
     return brand;
 }

 public String getColour() {
     return colour;
 }

// public String getMaterial() {
//     return material;
// }
 
 public boolean plastic() {
     return plastic;
 }

 public int getPrice() {
     return price;
 }
}

//Main class to use Staplen
public class UseStapler {
 public static void main(String args[]) {
     Staplen staplen1 = new Staplen();
     Staplen staplen2 = new Staplen();
     Staplen staplen3 = new Staplen();

     // Setting values for staplen1
     staplen1.Brand("ABC");
     staplen1.setPrice(100);
     staplen1.setColour("Blue");
     staplen1.plastic(true);

     // Setting values for staplen2
     staplen2.Brand("BCD");
     staplen2.setPrice(200);
     staplen2.setColour("Black");
     staplen2.plastic(true);

     // Setting values for staplen3
     staplen3.Brand("XYZ");
     staplen3.setPrice(300);
     staplen3.setColour("White");
     staplen3.plastic(false);

     // Array of Staplen objects
     Staplen[] a = { staplen1, staplen2, staplen3 };
     int count=0;
     // Loop to print details
     for (int i = 0; i < a.length; i++) {
    	 if(a[i].plastic==true)
    		 count++;
         System.out.println(a[i].seBrand() + " " + a[i].getColour() + " " + a[i].getPrice() + " " + a[i].plastic());
     }
     System.out.println(count);
 }
}
