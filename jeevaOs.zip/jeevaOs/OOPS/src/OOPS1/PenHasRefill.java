package OOPS1;

class Refill {
	private String color;
	private boolean isRefill;
	public void setcolor(String color) {
		this.color=color;
	}
	public void setRefill(boolean Refill) {
		this.isRefill=Refill;
	}
	public String getcolor() {
		return color;
	}
	public boolean getRefill() {
		return isRefill;
	}
}
class Pen {
	private String brand;
	private int price;
	private Refill fill;
	
}
public class PenHasRefill {

	public static void main(String[] args) {
		

	}

}
