package OOPS1;

public class UseCar {
	public static void main(String[] args) {
		car c= new car();
		engine en=new engine();
		c.setbrand("bmw");
		c.setprice(2000);
		c.sete(en);
		en.setenginecc(400);
		en.setmileage(400);
		System.out.println(c.gete().getenginecc()+" "+c.gete().getmileage());
	}
}

class engine {
	private int enginecc;
	private int mileage;
	public void setenginecc(int enginecc) {
		this.enginecc=enginecc;
	}
	public void setmileage(int mileage) {
		this.mileage=mileage;
	}
	public int getenginecc() {
		return enginecc;
	}
	public int getmileage() {
		return mileage;
	}
}
class car {
	private String brand;
	private int price;
	private engine e;
	public void setbrand(String brand) {
		this.brand=brand;
	}
	public void setprice(int price) {
		this.price=price;
	}
	public void sete(engine e) {
		this.e=e;
	}
	public engine gete() {
		return e;
	}
	public String getbrand() {
		return brand;
	}
	public int getprice() {
		return price;
	}
	
}
