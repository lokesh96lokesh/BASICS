package OOPS1;

class Shirt {
	private String color;
	private int price;
	private String size;
	
	public Shirt(String color,int price,String size){
		this.color=color;
		this.price=price;
		this.size=size;
	}
	public String toString() {
		return "Color:"+color+" "+" "+size;
	}
	public void setcolor(String color) {
		this.color=color;
	}
	public void setprice(int price) {
		this.price=price;
	}
	public void setsize(String size) {
		this.size=size;
	}
	public String getcolor() {
		return color;
	}
	public int getprice() {
		return price;
	}
	public String getsize() {
		return size;
	}
	
}
public class ShirtConstructer {
	public static void main(String[] args) {
		Shirt s= new Shirt("blue",3000,"M");
		System.out.println(s);

	}

}
