package OOPS1;

class Teacher {
	String name;
	int age;
	String subject;
}
class Human {
	String gender;
	float height;
	String qualification;
	Teacher teach;
}
public class humanHasATeacher {

	public static void main(String[] args) {
		Teacher t = new Teacher();
		t.name="dhanalakshmi";
		t.age=23;
		t.subject="database";
		Human h=new Human();
		h.gender="female";
		h.height=5.4f;
		h.qualification="B.com";
		h.teach=t;
		System.out.println(h.teach.name+" "+h.teach.age+" "+h.gender);
		
		
		

	}

}
