package OOPS1;
class Apple {
	private String color;
	private String types;
	private boolean isGood;
	 public void setcolor(String color) {
		 this.color=color;
	 }
	 public void settype(String types) {
		 this.types=types;
	 }
	 public void setisGood(boolean isGood) {
		 this.isGood=isGood;
	 }
	 public String getcolor() {
		 return color;
	 }
	 public String gettype() {
		 return types;
	 }
	 public boolean getgood() {
		 return isGood;
	 }
}
class Fruit {
	private String fruitname;
	private String fruitplace;
	private int km;
	private Apple app;
	public void setname(String fruitname) {
		 this.fruitname=fruitname;
	 }
	 public void setplace(String fruitplace) {
		 this.fruitplace=fruitplace;
	 }
	 public void setkm(int km) {
		 this.km=km;
	 }
	 public void setApple(Apple app) {
		 this.app=app;
	 }
	 public String getname() {
		 return fruitname;
	 }
	 public String getplace() {
		 return fruitplace;
	 }
	 public int getkm() {
		 return km;
	 }
	 public Apple getapp() {
		 return app;
	 }
	 
}
public class FruitHasApple {

	public static void main(String[] args) {
		Apple a= new Apple();
//		a.setcolor("green");
//		a.settype("small");
//		a.setisGood(true);
//		Fruit f= new Fruit();
//		f.setname("Apple");
//		f.setplace("himachal");
//		f.setkm(1500);
//		f.setApple(a);
//		//System.out.println(f.getapp().getcolor());
//		System.out.println(f.getname()+" "+f.getkm()+" "+f.getplace()+"\n"+a.getcolor()+" "+a.gettype()+" "+a.getgood());

	}

}
