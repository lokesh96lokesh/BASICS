package OOPS1;


class a {
	public String name(String a) {
		return a;
	}
	public String name(String a,String b) {
		return a+b;
	}
}
class b extends a {
	public String name(String a) {
		return a+"b";
	}
	public String name(String a,String b) {
		return a+b+"jeeva";
	}
}
public class Override {

	public static void main(String[] args) {
		b bb= new b();
		a aa= new a();
		System.out.println(bb.name("jeeva"));
		System.out.println(bb.name("jeeva","manoj"));
		
		System.out.println(aa.name("pradeep"));
		

	}

}
