package OOPS1;

class Bus {
	private String name;
	private String color;
	private int price;
	private boolean isPetrol;
	public Bus (String name,String color,int price,boolean isPetrol) {
		this.name=name;
		this.color=color;
		this.price=price;
		this.isPetrol=this.isPetrol;
	}
//	public String toString() {
//		return "BusName:"+name+" "+color+" "+price+" "+isPetrol;
//	}
	public void setname(String name) {
		this.name=name;
	}
	public void setcolor(String color) {
		this.color=color;
	}
	public void setprice(int price) {
		this.price=price;
	}
	public void setpetrol(boolean petrol) {
		this.isPetrol=petrol;
	}
	public String getname() {
		return name;
	}
	public String getcolor() {
		return color;
	}
	public int getprice() {
		return price;
	}
	public boolean getpetrol() {
		return isPetrol;
	}
	
}
public class BusConstructer {
	public static void main(String[] args) {
		Bus b= new Bus("MR", "Red", 20000, false);
		System.out.println(b.getname());
	}

}
