package OOPS3Polymorphism;

public class override {
	public static void main(String[] args) {
		AxiosBank a = new AxiosBank();
		System.out.println(a.getinterest(1000));

	}
}

class Bank {
	public int getinterest(int amount) {
		return amount*10/100;
	}
}

class AxiosBank extends Bank{
//	public int getinterest(int amount) {
//		return amount*15/100;
//	}
}