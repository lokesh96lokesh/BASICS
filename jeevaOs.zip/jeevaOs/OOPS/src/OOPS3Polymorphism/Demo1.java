package OOPS3Polymorphism;

public class Demo1 {

	public static void main(String[] args) {
		name nam = new name();
		System.out.println(nam.getnam("jeeva"));
		System.out.println(nam.getnam("jeeva","dinesh"));

	}
}

class name {
	public String getnam(String n) {
		return n;
	}
	public String getnam(String n,String m) {
		return n.concat(m);
	}
}