package OOPS3Polymorphism;

public class UseChemistryTeacher {
	public static void main(String[] args) {
		String a[]=args[0].split(",");
		ChemistryTeacher ct = new ChemistryTeacher();
		ct.setdesignation(a[0]);
		ct.setcollegeName(a[1]);
		System.out.println(ct.getdesignation()+"\n"+ct.getcollegeName()+"\n"+ct.does(a[2])+"\n"+ct.mainSubject(a[3]));

	}
}
class Teacher {
	private String designation;
	private String collegeName;
	public String does(String work) {
		return work;
	}
	public void setdesignation(String designation) {
		this.designation=designation;
	}
	public void setcollegeName(String collegeName) {
		this.collegeName=collegeName;
	}
	public String getdesignation() {
		return designation;
	}
	public String getcollegeName() {
		return collegeName;
	}
}

class ChemistryTeacher extends Teacher{
		public String mainSubject(String subject) {
			return subject;
	}
	
	public String does(String working) {
		return working;
	}
}