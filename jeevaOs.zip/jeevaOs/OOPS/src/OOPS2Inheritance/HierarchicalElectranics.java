package OOPS2Inheritance;

public class HierarchicalElectranics {
	public static void main(String[] args) {
		Phone ph = new Phone("ELECTRONICITEMS",10,"VIVO","Y56",20000);
		Laptop lap = new Laptop("ELECTRONICITEMS",5,"DELL","I7",85000);
		System.out.println(ph);
		System.out.println();
		System.out.println(lap);
		
	}
}

class Electranics {
	private String Ename;
	private int QTY;
	public Electranics(String Ename,int QTY) {
		this.Ename=Ename;
		this.QTY=QTY;
	}
	public String toString() {
		return "ENAME: "+Ename+"QUANTITY: "+QTY;
	}
}
class Phone extends Electranics {
	private String Pname;
	private String model;
	private int PhonePrice;
	public Phone(String Ename,int QTY,String Pname,String model,int Phonecost) {
		super(Ename,QTY);
		this.Pname=Pname;
		this.model=model;
		this.PhonePrice=Phonecost;
	}
	public String toString() {
		return "PHONENAME: "+Pname+" Model: "+model+" PHONEPRICE: "+PhonePrice;
	}
}
class Laptop extends Electranics {
	private String Lname;
	private String model;
	private int LaptopPrice;
	public Laptop(String Ename,int QTY,String Lname,String model,int LaptopPrice) {
		super(Ename,QTY);
		this.Lname=Lname;
		this.model=model;
		this.LaptopPrice=LaptopPrice;
	}
	public String toString() {
		return "LAPTOPNAME: "+Lname+" LAPMODEL: "+model+" LAPTOPPRICE: "+LaptopPrice;
	}
}
