package OOPS2Inheritance;

public class MultilevelFruitsJuice {
	public static void main(String[] args) {
		ApppleJuice ju= new ApppleJuice("Apple",150,"Red","10g","India",200,"Sweet");
		System.out.println(ju);
	}
}

class Fruit {
	private String name;
	private int price;
	private String color;
	public Fruit (String name,int price,String color) {
		this.name=name;
		this.price=price;
		this.color=color;
	}
	public String toString() {
		return "FruitName: "+name+"FruitPrice: "+price+"FruitColor: "+color;
	}
}
class Apple extends Fruit {
	private String weight;
	private String place;
	public Apple(String name,int price,String color,String weight,String place) {
		super(name,price,color);
		this.place=place;
		this.weight=weight;
	}
	public String toString() {
		return super.toString()+"ApplePlace: "+place+"AppleWeight: "+weight;
	}
}
class ApppleJuice extends Apple {
	private int rate;
	private String taste;
	public ApppleJuice(String name,int price,String color,String weight,String place,int rate,String taste) {
		super(name,price,color,weight,place);
		this.rate=rate;
		this.taste=taste;
	}
	public String toString() {
		return super.toString()+"JuiceRate: "+rate+"JuiceTaste: "+taste;
	}
}
