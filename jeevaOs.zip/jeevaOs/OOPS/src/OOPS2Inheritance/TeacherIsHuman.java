package OOPS2Inheritance;

public class TeacherIsHuman {
	public static void main(String[] args) {
		Teacher teach = new Teacher("ajay", "Male", 24,1,"BCA");
		System.out.println(teach);
	}

}

class Human {
	private String name;
	private String gender;
	private int age;
	
	public Human(String name,String gender,int age) {
		this.name=name;
		this.gender=gender;
		this.age=age;
	}
	public String toString() {
		return name+" "+gender+" "+age;
	}
}
class Teacher extends Human {
	private int exp;
	private String degree;
	public Teacher(String name, String gender, int age,int exp,String degree) {
		super(name, gender, age);
		this.exp=exp;
		this.degree=degree;
	}
	public String toString() {
		return super.toString()+" "+exp+" "+degree;
	}
	
}