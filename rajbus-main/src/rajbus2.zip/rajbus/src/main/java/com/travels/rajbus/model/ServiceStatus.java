package com.travels.rajbus.model;

public class ServiceStatus {
	
	private String mesaage;
	private String status;
	private String result;
	public String getMesaage() {
		return mesaage;
	}
	public void setMesaage(String mesaage) {
		this.mesaage = mesaage;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		result = result;
	}
	

}
